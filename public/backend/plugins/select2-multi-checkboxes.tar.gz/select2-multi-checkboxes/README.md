# select2-multi-checkboxes
Plugin to select2 (https://github.com/select2/select2) allowing multiple selection while retain old good dropdown.


Some of developers (including me) thinks that multiple selection in select2 is ugly due to oversized display of selected items.

![](https://cloud.githubusercontent.com/assets/9192409/20893500/4e4a8d4c-bb12-11e6-9c46-1b90f70aaca8.png)

With small effort it can be replaced by normal drop down list with checkboxes.

![](https://cloud.githubusercontent.com/assets/9192409/20894631/83940e7a-bb16-11e6-8be6-19ddd5ce355f.png)![](https://cloud.githubusercontent.com/assets/9192409/20894652/9bbbcc90-bb16-11e6-8b9d-424760e2de36.png)

## Docs (comming soon)
Take look into https://jsfiddle.net/wasikuss/7ak9skbb/ to learn how to use it.
